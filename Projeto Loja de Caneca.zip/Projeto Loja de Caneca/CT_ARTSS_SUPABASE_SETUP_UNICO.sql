-- =====================================================================
-- CT ARTSS V15 | SETUP ÚNICO — COLE INTEIRO NO SUPABASE > SQL EDITOR > RUN
-- =====================================================================
-- Não publique este arquivo dentro do Netlify.
-- Login inicial: caneca | senha: caneca123
-- Você pode editar as DUAS variáveis do bloco de instalação no item 4.
-- Se rodar outra vez, a senha NÃO volta ao padrão: o seed não substitui ADM existente.
-- Segurança pequena e necessária: bcrypt, token temporário e RLS.
-- Usar no front apenas Project URL + publishable key (ou anon legada).

-- 1) Dependência de hash de senha. No Supabase, pgcrypto reside em extensions.
create schema if not exists extensions;
create extension if not exists pgcrypto with schema extensions;
create schema if not exists ct_private;
revoke all on schema ct_private from public, anon, authenticated;

-- 2) Catálogo visível ao público: quatro modelos e quatro inspirações.
create table if not exists public.ct_catalog_status (
  id text primary key,
  label text not null,
  group_key text not null check (group_key in ('model', 'inspiration')),
  sort_order integer not null default 0,
  is_sold_out boolean not null default false,
  updated_at timestamptz not null default now()
);

-- O seed mantém o status escolhido pelo ADM caso você execute novamente.
insert into public.ct_catalog_status (id,label,group_key,sort_order,is_sold_out) values
  ('porcelana-simples',       'Porcelana simples · R$ 35,00',          'model',  10,false),
  ('polimero',               'Sublimática de polímero · R$ 29,90',   'model',  20,false),
  ('sublimacao-porcelana',   'Sublimática de porcelana · R$ 32,00',  'model',  30,false),
  ('porcelana-detalhada',    'Porcelana detalhada · R$ 40,00',       'model',  40,false),
  ('nome',                   'Inspiração · Com seu nome',            'inspiration', 50,false),
  ('familia',                'Inspiração · Família',                 'inspiration', 60,false),
  ('divertida',              'Inspiração · Divertidas',              'inspiration', 70,false),
  ('pet',                    'Inspiração · Para mães de pet',          'inspiration', 80,false)
on conflict (id) do update set
  label=excluded.label, group_key=excluded.group_key, sort_order=excluded.sort_order;

alter table public.ct_catalog_status enable row level security;
drop policy if exists ct_catalog_public_read on public.ct_catalog_status;
create policy ct_catalog_public_read on public.ct_catalog_status
  for select to anon, authenticated using (true);
revoke all on public.ct_catalog_status from public, anon, authenticated;
grant select on public.ct_catalog_status to anon, authenticated;

-- 3) Tabelas privadas (não acessíveis diretamente à chave pública).
create table if not exists ct_private.admin_account (
  id smallint primary key default 1 check (id=1),
  username text not null unique,
  password_hash text not null,
  failed_attempts integer not null default 0,
  locked_until timestamptz,
  updated_at timestamptz not null default now()
);
create table if not exists ct_private.admin_session (
  token_hash text primary key,
  expires_at timestamptz not null,
  created_at timestamptz not null default now()
);
revoke all on ct_private.admin_account, ct_private.admin_session from public, anon, authenticated;

-- 4) LOGIN INICIAL: EDITE AQUI ANTES DA PRIMEIRA INSTALAÇÃO, SE QUISER.
do $ct_initial_account$
declare
  initial_login text := 'caneca';
  initial_password text := 'caneca123';
begin
  if initial_login !~ '^[a-zA-Z0-9._-]{3,32}$' then
    raise exception 'Login precisa ter 3 a 32 caracteres (letras, números, ponto, _ ou -).';
  end if;
  if length(initial_password) < 8 then
    raise exception 'Senha inicial precisa ter pelo menos 8 caracteres.';
  end if;
  insert into ct_private.admin_account(id,username,password_hash)
  values (1,lower(initial_login),extensions.crypt(initial_password,extensions.gen_salt('bf',10)))
  on conflict (id) do nothing;
end;
$ct_initial_account$;

-- 5) Verificação interna de token: o banco guarda só o HASH do token.
create or replace function ct_private.session_valid(p_token text)
returns boolean
language sql stable security definer set search_path = ''
as $function$
  select case when p_token is null or p_token !~ '^[0-9a-f]{64}$' then false
    else exists(
      select 1 from ct_private.admin_session s
      where s.token_hash = encode(extensions.digest(p_token,'sha256'),'hex')
        and s.expires_at > now()
    ) end;
$function$;
revoke all on function ct_private.session_valid(text) from public, anon, authenticated;

-- 6) LOGIN: limite de 6 falhas / bloqueio temporário de 10 minutos.
create or replace function public.ct_admin_login(p_username text,p_password text)
returns jsonb
language plpgsql security definer set search_path = ''
as $function$
declare
  a ct_private.admin_account%rowtype;
  v_token text;
  v_expires timestamptz;
  v_fail integer;
begin
  if p_username is null or p_password is null
     or length(p_username)>64 or length(p_password)>128 then
    return jsonb_build_object('ok',false,'error','Credenciais inválidas.');
  end if;
  select * into a from ct_private.admin_account where id=1 for update;
  if not found then
    return jsonb_build_object('ok',false,'error','ADM ainda não instalado. Rode o SQL.');
  end if;
  if a.locked_until is not null and a.locked_until>now() then
    return jsonb_build_object('ok',false,'error','Muitas tentativas. Tente novamente em 10 minutos.');
  end if;
  if lower(btrim(p_username))<>a.username
     or extensions.crypt(p_password,a.password_hash)<>a.password_hash then
    v_fail := a.failed_attempts + 1;
    update ct_private.admin_account set failed_attempts=v_fail,
      locked_until=case when v_fail>=6 then now()+interval '10 minutes' else null end
      where id=1;
    return jsonb_build_object('ok',false,'error','Login ou senha incorretos.');
  end if;
  update ct_private.admin_account set failed_attempts=0,locked_until=null where id=1;
  delete from ct_private.admin_session where expires_at<=now();
  v_token := encode(extensions.gen_random_bytes(32),'hex');
  v_expires := now()+interval '8 hours';
  insert into ct_private.admin_session(token_hash,expires_at)
  values(encode(extensions.digest(v_token,'sha256'),'hex'),v_expires);
  return jsonb_build_object('ok',true,'token',v_token,'username',a.username,'expires_at',v_expires);
end;
$function$;

-- 7) Recupera nome do usuário somente com sessão válida.
create or replace function public.ct_admin_verify(p_token text)
returns jsonb
language plpgsql security definer set search_path = ''
as $function$
declare v_username text;
begin
  if not ct_private.session_valid(p_token) then
    return jsonb_build_object('ok',false,'error','Sessão expirada.');
  end if;
  select username into v_username from ct_private.admin_account where id=1;
  return jsonb_build_object('ok',true,'username',v_username);
end;
$function$;

-- 8) Somente este RPC, após validar a sessão, pode editar o estoque.
create or replace function public.ct_admin_set_status(p_token text,p_id text,p_sold_out boolean)
returns jsonb
language plpgsql security definer set search_path = ''
as $function$
declare row_updated public.ct_catalog_status%rowtype;
begin
  if not ct_private.session_valid(p_token) then
    return jsonb_build_object('ok',false,'error','Sessão expirada. Entre novamente.');
  end if;
  if p_id is null or p_sold_out is null then
    return jsonb_build_object('ok',false,'error','Seleção inválida.');
  end if;
  update public.ct_catalog_status
     set is_sold_out=p_sold_out,updated_at=now()
   where id=p_id returning * into row_updated;
  if not found then
    return jsonb_build_object('ok',false,'error','Item não encontrado.');
  end if;
  return jsonb_build_object('ok',true,'item',to_jsonb(row_updated));
end;
$function$;

-- 9) Alterar LOGIN e SENHA no próprio painel, confirmando a senha atual.
-- A mudança invalida TODAS as sessões anteriores.
create or replace function public.ct_admin_change_credentials(
  p_token text,p_current_password text,p_new_username text,p_new_password text
)
returns jsonb
language plpgsql security definer set search_path = ''
as $function$
declare a ct_private.admin_account%rowtype;
begin
  if not ct_private.session_valid(p_token) then
    return jsonb_build_object('ok',false,'error','Sessão expirada. Entre novamente.');
  end if;
  if p_current_password is null or p_new_username is null or p_new_password is null then
    return jsonb_build_object('ok',false,'error','Preencha todos os campos.');
  end if;
  if p_new_username !~ '^[a-zA-Z0-9._-]{3,32}$' or length(p_new_password)<8
     or length(p_new_password)>72 then
    return jsonb_build_object('ok',false,'error','Login: 3–32 caracteres simples. Senha: 8–72 caracteres.');
  end if;
  select * into a from ct_private.admin_account where id=1 for update;
  if extensions.crypt(p_current_password,a.password_hash)<>a.password_hash then
    return jsonb_build_object('ok',false,'error','A senha atual está incorreta.');
  end if;
  update ct_private.admin_account set
    username=lower(p_new_username),
    password_hash=extensions.crypt(p_new_password,extensions.gen_salt('bf',10)),
    updated_at=now(),failed_attempts=0,locked_until=null
    where id=1;
  delete from ct_private.admin_session where token_hash is not null;
  return jsonb_build_object('ok',true,'message','Login e senha alterados. Entre novamente.');
end;
$function$;

-- 10) Sair do painel.
create or replace function public.ct_admin_logout(p_token text)
returns jsonb
language plpgsql security definer set search_path = ''
as $function$
begin
  if p_token is not null and p_token ~ '^[0-9a-f]{64}$' then
    delete from ct_private.admin_session
      where token_hash=encode(extensions.digest(p_token,'sha256'),'hex');
  end if;
  return jsonb_build_object('ok',true);
end;
$function$;

-- Apenas as funções acima são liberadas ao navegador. Nada de writes diretos.
revoke all on function public.ct_admin_login(text,text) from public;
revoke all on function public.ct_admin_verify(text) from public;
revoke all on function public.ct_admin_set_status(text,text,boolean) from public;
revoke all on function public.ct_admin_change_credentials(text,text,text,text) from public;
revoke all on function public.ct_admin_logout(text) from public;
grant execute on function public.ct_admin_login(text,text) to anon,authenticated;
grant execute on function public.ct_admin_verify(text) to anon,authenticated;
grant execute on function public.ct_admin_set_status(text,text,boolean) to anon,authenticated;
grant execute on function public.ct_admin_change_credentials(text,text,text,text) to anon,authenticated;
grant execute on function public.ct_admin_logout(text) to anon,authenticated;

-- =====================================================================
-- EDITAR LOGIN / SENHA PELO PRÓPRIO SQL, FUTURAMENTE (EXEMPLO):
-- Troque NOVO_LOGIN e NOVA_SENHA (mínimo 8 caracteres) e execute só abaixo:
--
-- update ct_private.admin_account
-- set username=lower('NOVO_LOGIN'),
--     password_hash=extensions.crypt('NOVA_SENHA',extensions.gen_salt('bf',10)),
--     failed_attempts=0,locked_until=null,updated_at=now()
-- where id=1;
-- delete from ct_private.admin_session where token_hash is not null;
--
-- Exemplo para marcar uma caneca manualmente como ESGOTADA:
-- update public.ct_catalog_status set is_sold_out=true,updated_at=now()
-- where id='porcelana-simples';
-- Para voltar: is_sold_out=false.
-- =====================================================================


-- V22: instalação nova também já recebe a RPC atualizada.
-- CT ARTSS V22 — execute SOMENTE este arquivo no SQL Editor do Supabase existente.
-- Compatível com a instalação V15/V17/V20/V21. Idempotente; pode rodar novamente.
-- Não redefine login ou senha, nem altera preços, estoque, fotos ou pedidos.
-- Nova RPC evita conflito de versões com a função antiga.

create or replace function public.ct_admin_update_access(
  p_token text,
  p_current_password text,
  p_new_username text,
  p_new_password text
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $ct_v22$
declare
  a ct_private.admin_account%rowtype;
  v_name text;
  v_hash text;
  v_change_name boolean;
  v_change_password boolean;
begin
  if not ct_private.session_valid(p_token) then
    return jsonb_build_object('ok',false,'error','Sessão expirada. Entre novamente no ADM.');
  end if;

  if p_current_password is null or length(p_current_password)=0 then
    return jsonb_build_object('ok',false,'error','Informe a senha atual para confirmar a alteração.');
  end if;

  select * into a from ct_private.admin_account where id=1 for update;
  if not found then
    return jsonb_build_object('ok',false,'error','Conta administrativa não encontrada.');
  end if;

  if extensions.crypt(p_current_password,a.password_hash) is distinct from a.password_hash then
    return jsonb_build_object('ok',false,'error','A senha atual não confere. O acesso não foi modificado.');
  end if;

  v_name := lower(btrim(coalesce(p_new_username,'')));
  if v_name='' then v_name:=a.username; end if;
  if v_name !~ '^[a-z0-9._-]{3,32}$' then
    return jsonb_build_object('ok',false,'error','Login: use 3 a 32 caracteres (letras, números, ponto, _ ou -).');
  end if;

  v_change_name := v_name is distinct from a.username;
  v_change_password := nullif(p_new_password,'') is not null;

  if v_change_password and (length(p_new_password)<8 or octet_length(p_new_password)>72) then
    return jsonb_build_object('ok',false,'error','Nova senha: mínimo de 8 caracteres e máximo de 72 bytes.');
  end if;

  if v_change_password and extensions.crypt(p_new_password,a.password_hash)=a.password_hash then
    return jsonb_build_object('ok',false,'error','A nova senha deve ser diferente da senha atual.');
  end if;

  if not v_change_name and not v_change_password then
    return jsonb_build_object('ok',false,'error','Nada foi alterado. Preencha uma nova senha ou mude o login.');
  end if;

  v_hash := a.password_hash;
  if v_change_password then
    v_hash:=extensions.crypt(p_new_password,extensions.gen_salt('bf',10));
  end if;

  update ct_private.admin_account
     set username=v_name,
         password_hash=v_hash,
         failed_attempts=0,
         locked_until=null,
         updated_at=now()
   where id=1;

  -- A troca encerra todas as sessões antigas. O novo ADM verifica as credenciais
  -- realizando um novo login logo depois desta confirmação do banco.
  delete from ct_private.admin_session where token_hash is not null;

  return jsonb_build_object(
    'ok',true,
    'username',v_name,
    'changed_login',v_change_name,
    'changed_password',v_change_password,
    'flow_version',22,
    'message','Alteração salva no banco. Entre novamente com os novos dados.'
  );
end;
$ct_v22$;

-- A conta privada continua inacessível via API: só a RPC validada altera os dados.
revoke all on function public.ct_admin_update_access(text,text,text,text) from public, anon, authenticated;
grant execute on function public.ct_admin_update_access(text,text,text,text) to anon,authenticated;

-- Supabase/PostgREST: recarregar catálogo de funções após alteração de RPC.
notify pgrst, 'reload schema';

select 'CT Artss V22: troca de acesso atualizada SEM redefinir a senha atual.' as resultado;
