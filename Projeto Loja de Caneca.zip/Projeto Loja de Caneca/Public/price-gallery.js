/* CT Artss V24: each catalog item has one availability status, even with two photos. */
(()=>{
  for(const gallery of document.querySelectorAll('.price-photo--pair')){
    const main=gallery.querySelector('.price-photo-primary');
    const thumb=gallery.querySelector('.price-photo-swap img');
    const control=gallery.querySelector('.price-photo-swap');
    if(!main||!thumb||!control)continue;
    control.addEventListener('click',()=>{
      const src=main.getAttribute('src'), alt=main.alt;
      main.setAttribute('src',thumb.getAttribute('src'));
      main.alt=thumb.alt;
      thumb.setAttribute('src',src);
      thumb.alt=alt;
      control.setAttribute('aria-label',`Ver outra foto de ${gallery.closest('.price-card')?.querySelector('h3')?.textContent||'caneca'}`);
    });
  }
})();
