
import * as THREE from 'https://esm.sh/three@0.185.0';

const hero = document.querySelector('#heroVisual');
const studio = document.querySelector('#studioViewer');
const canvas = document.querySelector('#mugCanvas');
const fallback = document.querySelector('#studioFlatPreview');
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

const COLORS = {
  cream:{base:'#fff8ef',rim:0xfff8ef,ink:'#172538',accent:'#eb6688'},
  pink:{base:'#f5c4ce',rim:0xf5c4ce,ink:'#4b2837',accent:'#c64366'},
  blue:{base:'#d6eafa',rim:0xd6eafa,ink:'#193650',accent:'#e36c94'},
  mint:{base:'#ceebda',rim:0xceebda,ink:'#1a453b',accent:'#dc6e83'},
  yellow:{base:'#ffe2a2',rim:0xffe2a2,ink:'#513728',accent:'#d45465'}
};

const options = { text:'Feito com amor', color:'cream', motif:'hearts', image:null, drawing:null };
const CYLINDER_STRETCH = 1.60;
const artCanvas = document.createElement('canvas');
artCanvas.width = 2048;
artCanvas.height = 1024;
const ctx = artCanvas.getContext('2d');

let renderer = null, scene = null, camera = null, mug = null;
let texture = null, bodyMat = null, porcelainMat = null, innerMat = null, coffeeMat = null;
let activeStage = hero;
let targetYaw = 0.35, yaw = 0.35, targetPitch = -0.10, pitch = -0.10;
let dragging = false, lastX = 0, lastY = 0, lastInteraction = performance.now();
let renderReady = false, animationSeconds = 0, lastFrame = 0;
const initialParent = canvas.parentNode;
const initialNext = canvas.nextSibling;

function isTransparentImage(img){
  try {
    const c = document.createElement('canvas');
    c.width = 48; c.height = 48;
    const cx = c.getContext('2d', { willReadFrequently: true });
    cx.drawImage(img, 0, 0, 48, 48);
    const data = cx.getImageData(0, 0, 48, 48).data;
    for(let i = 3; i < data.length; i += 4){
      if(data[i] < 220) return true;
    }
  }catch(e){}
  return false;
}

function fitFont(value, maxWidth, start=122, minimum=48){
  let size = start;
  do {
    ctx.font = `700 ${size}px Caveat, cursive`;
    if(ctx.measureText(value).width <= maxWidth) break;
    size -= 3;
  } while(size > minimum);
  return size;
}
function doodle(type,x,y,size,color,rotation=0){
  ctx.save();
  ctx.translate(x,y);
  ctx.scale(1 / CYLINDER_STRETCH, 1);
  ctx.rotate(rotation);
  ctx.fillStyle=color;
  if(type==='hearts'){
    ctx.beginPath();ctx.moveTo(0,size*.35);
    ctx.bezierCurveTo(-size*.85,-size*.1,-size*.38,-size*.65,0,-size*.22);
    ctx.bezierCurveTo(size*.38,-size*.65,size*.85,-size*.1,0,size*.35);
    ctx.fill();
  }else if(type==='stars'){
    ctx.beginPath();for(let i=0;i<8;i++){
      const a=-Math.PI/2+i*Math.PI/4;
      const r=i%2?size*.19:size*.53;
      if(i===0)ctx.moveTo(Math.cos(a)*r,Math.sin(a)*r); else ctx.lineTo(Math.cos(a)*r,Math.sin(a)*r);
    }ctx.closePath();ctx.fill();
  }else if(type==='flower'){
    for(let k=0;k<5;k++){
      const a=k*Math.PI*2/5;
      ctx.beginPath();
      ctx.ellipse(Math.cos(a)*size*.23,Math.sin(a)*size*.23,size*.24,size*.13,a,0,Math.PI*2);
      ctx.fill();
    }
    ctx.fillStyle='#f0b343';ctx.beginPath();ctx.arc(0,0,size*.13,0,Math.PI*2);ctx.fill();
  }
  ctx.restore();
}
function roundedRect(x,y,w,h,r){ctx.beginPath();ctx.roundRect(x,y,w,h,r);}
function wrapText(str,maxWidth,maxLines=2){
  const parts = str.trim().split(/\s+/); const lines=[]; let line='';
  for(const part of parts){
    const test=line?line+' '+part:part;
    if(ctx.measureText(test).width > maxWidth && line){ lines.push(line); line=part; }
    else line=test;
  }
  if(line) lines.push(line);
  if(lines.length > maxLines){
    const keep = lines.slice(0,maxLines-1);
    keep.push(lines.slice(maxLines-1).join(' '));
    return keep;
  }
  return lines;
}
function drawArtwork(){
  const W = artCanvas.width, H = artCanvas.height;
  const palette = COLORS[options.color] || COLORS.cream;
  ctx.clearRect(0,0,W,H);
  ctx.fillStyle = palette.base;
  ctx.fillRect(0,0,W,H);

  const sheen = ctx.createLinearGradient(0,0,W,0);
  sheen.addColorStop(0,'rgba(255,255,255,.15)');
  sheen.addColorStop(.18,'rgba(255,255,255,.02)');
  sheen.addColorStop(.5,'rgba(255,255,255,0)');
  sheen.addColorStop(.82,'rgba(255,255,255,.04)');
  sheen.addColorStop(1,'rgba(255,255,255,.14)');
  ctx.fillStyle = sheen; ctx.fillRect(0,0,W,H);

  const marks = [[505,220,48,-.2],[594,740,34,.17],[1430,208,42,.08],[1510,716,37,-.18],[694,138,22,-.1],[1310,830,22,.16]];
  if(options.motif !== 'none') marks.forEach(([x,y,size,angle])=>doodle(options.motif,x,y,size,palette.accent,angle));

  const centre = W / 2;
  ctx.textAlign='center';ctx.textBaseline='middle';

  const message = (options.text || '').trim();
  const hasText = message.length > 0;
  const hasDrawing = options.drawing instanceof HTMLCanvasElement;
  const hasImageObj = !!(options.image && options.image.complete && options.image.naturalWidth);
  const hasImage = hasImageObj || hasDrawing;
  const photoLayout = options.photoLayout || 'front';
  const isDuo = photoLayout === 'duo' && hasText; // Duo mode: foto na frente, frase no verso
  const photoStyle = options.photoStyle || 'polaroid';
  const photoScale = Math.max(0.7, Math.min(1.3, Number(options.photoScale) || 1.0));

  if(hasImageObj){
    const img = options.image;
    const imgAspect = img.naturalWidth / img.naturalHeight;
    // Compensa a curvatura cilíndrica para preservar proporções naturais (1:1, 3:4, etc.)
    const canvasAspect = imgAspect / CYLINDER_STRETCH;

    const baseMaxW = (hasText && !isDuo) ? 430 : 580;
    const baseMaxH = (hasText && !isDuo) ? 390 : 560;
    const maxW = baseMaxW * photoScale;
    const maxH = baseMaxH * photoScale;

    let w, h;
    if(canvasAspect >= maxW / maxH){
      w = maxW;
      h = w / canvasAspect;
    } else {
      h = maxH;
      w = h * canvasAspect;
    }

    const y = (hasText && !isDuo) ? 370 : 490;
    const transparent = isTransparentImage(img);

    ctx.save();
    if(photoStyle === 'circle' && !transparent){
      // Foto redonda / medalhão perfeitamente circular em 3D (object-fit: cover)
      const diaY = Math.min(w * CYLINDER_STRETCH, h);
      const diaX = diaY / CYLINDER_STRETCH;
      const radX = diaX / 2;
      const radY = diaY / 2;

      // Moldura circular branca com sombra suave
      ctx.save();
      ctx.shadowColor = 'rgba(20, 34, 56, 0.16)';
      ctx.shadowBlur = 16;
      ctx.shadowOffsetY = 4;
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.ellipse(centre, y, radX + 14 / CYLINDER_STRETCH, radY + 14, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      // Recorte circular da foto sem distorcer (object-fit cover)
      let drawW, drawH;
      if(imgAspect >= 1.0){
        drawH = diaY;
        drawW = (drawH * imgAspect) / CYLINDER_STRETCH;
      } else {
        drawW = diaY / CYLINDER_STRETCH;
        drawH = (drawW * CYLINDER_STRETCH) / imgAspect;
      }
      ctx.save();
      ctx.beginPath();
      ctx.ellipse(centre, y, radX, radY, 0, 0, Math.PI * 2);
      ctx.clip();
      ctx.drawImage(img, centre - drawW/2, y - drawH/2, drawW, drawH);
      ctx.restore();
    } else if(photoStyle === 'polaroid' && !transparent){
      const pad = 12;
      const cardW = w + pad * 2;
      const cardH = h + pad * 2;
      const cardR = Math.min(18, Math.min(cardW, cardH) * 0.12);

      // Moldura fotográfica branca proporcional às dimensões exatas da imagem
      ctx.save();
      ctx.shadowColor = 'rgba(20, 34, 56, 0.14)';
      ctx.shadowBlur = 14;
      ctx.shadowOffsetY = 4;
      ctx.fillStyle = '#ffffff';
      roundedRect(centre - cardW/2, y - cardH/2, cardW, cardH, cardR);
      ctx.fill();
      ctx.restore();

      const innerR = Math.max(4, cardR - 4);
      roundedRect(centre - w/2, y - h/2, w, h, innerR);
      ctx.clip();
      ctx.drawImage(img, centre - w/2, y - h/2, w, h);
    } else {
      // Estampa direta na cerâmica (ou imagem transparente)
      if(!transparent){
        roundedRect(centre - w/2, y - h/2, w, h, 14);
        ctx.clip();
      }
      ctx.drawImage(img, centre - w/2, y - h/2, w, h);
    }
    ctx.restore();
  }

  // O desenho transparente é aplicado sobrepondo à textura do produto
  if(hasDrawing){
    const draw = options.drawing;
    const drawAspect = draw.width / draw.height;
    const canvasDrawAspect = drawAspect / CYLINDER_STRETCH;
    const baseDrawW = (hasText && !isDuo) ? 440 : 580;
    const baseDrawH = (hasText && !isDuo) ? 380 : 550;
    const maxW = baseDrawW * photoScale;
    const maxH = baseDrawH * photoScale;
    let w, h;
    if(canvasDrawAspect >= maxW / maxH){
      w = maxW;
      h = w / canvasDrawAspect;
    } else {
      h = maxH;
      w = h * canvasDrawAspect;
    }
    const y = (hasText && !isDuo) ? (hasImageObj ? 370 : 375) : 490;
    ctx.drawImage(draw, centre - w/2, y - h/2, w, h);
  }

  if(hasText){
    const maxWidth = 780;
    if(isDuo){
      // MODO DUO: Frase personalizada impressa no VERSO da caneca (x = 0 e x = W)
      const textY = 490;
      let size = fitFont(message, maxWidth, 126, 56);
      let lines;
      do {
        ctx.font=`700 ${size}px Caveat, cursive`;
        lines=wrapText(message, maxWidth, 2);
        if(lines.every(line=>ctx.measureText(line).width<=maxWidth)) break;
        size -= 3;
      } while(size>48);
      const lineHeight=size*.92;
      ctx.fillStyle=palette.ink;
      ctx.font=`700 ${size}px Caveat, cursive`;
      [0, W].forEach(posX => {
        lines.forEach((line,i)=>ctx.fillText(line, posX, textY+(i-(lines.length-1)/2)*lineHeight, maxWidth));
      });
      if(options.motif !== 'none'){
        doodle(options.motif, 138, textY - 110, 36, palette.accent);
        doodle(options.motif, W - 138, textY + 110, 36, palette.accent);
      }
    } else {
      // MODO FRENTE ÚNICA: Texto embaixo da imagem na frente
      const textY = hasImage ? 746 : 495;
      let size = fitFont(message,maxWidth,hasImage?96:132,58);
      let lines;
      do {
        ctx.font=`700 ${size}px Caveat, cursive`;
        lines=wrapText(message,maxWidth,2);
        if(lines.every(line=>ctx.measureText(line).width<=maxWidth)) break;
        size -= 3;
      } while(size>48);
      const lineHeight=size*.92;
      ctx.fillStyle=palette.ink;
      ctx.font=`700 ${size}px Caveat, cursive`;
      lines.forEach((line,i)=>ctx.fillText(line,centre,textY+(i-(lines.length-1)/2)*lineHeight,maxWidth));
    }
  } else if(!hasImage){
    ctx.fillStyle=palette.ink; ctx.font='700 100px Caveat, cursive'; ctx.fillText('Sua ideia aqui',centre,495,720);
  }

  // A frente da caneca fica 100% limpa para a arte e frase do cliente.
  // A assinatura de ateliê da marca fica no verso.
  if(!isDuo){
    ctx.fillStyle=palette.ink; ctx.font='700 112px Caveat, cursive';
    ctx.fillText('CT artss',0,472); ctx.fillText('CT artss',W,472);
    ctx.font='600 44px Caveat, cursive';
    ctx.fillText('feito com carinho',0,550); ctx.fillText('feito com amor',W,550);
    if(options.motif !== 'none'){
      doodle(options.motif,132,270,36,palette.accent);
      doodle(options.motif,W-132,700,36,palette.accent);
    }
  } else {
    ctx.fillStyle=palette.ink;ctx.globalAlpha=.45;
    ctx.font='600 36px Caveat, cursive';
    [0, W].forEach(posX => ctx.fillText('CT artss · feito com carinho', posX, 840, 500));
    ctx.globalAlpha=1;
  }

  if(texture) texture.needsUpdate = true;
  if(bodyMat) bodyMat.color.setStyle(palette.base);
  if(porcelainMat) porcelainMat.color.setHex(palette.rim);
  if(innerMat) innerMat.color.setStyle(palette.base === '#fff8ef' ? '#f7f0e7' : '#faf4ed');
  if(fallback && !renderReady){ fallback.src = artCanvas.toDataURL('image/png'); fallback.hidden = false; }
}

function createBodyProfile(outer=true){
  const inset = outer ? 0 : 0.17;
  const topR = 1.20 - inset;
  const neckR = 1.18 - inset;
  const midR = 1.16 - inset;
  const botR = 1.06 - inset;
  const points = [
    new THREE.Vector2(0.86 - inset*0.6, -1.05),
    new THREE.Vector2(botR, -1.01),
    new THREE.Vector2(botR + 0.02, -0.70),
    new THREE.Vector2(midR, -0.10),
    new THREE.Vector2(midR + 0.01, 0.55),
    new THREE.Vector2(neckR, 0.90),
    new THREE.Vector2(topR, 1.00),
    new THREE.Vector2(topR - 0.01, 1.06)
  ];
  const segments = 160;
  const geom = new THREE.LatheGeometry(points, segments);
  if(outer){
    const lengths = [0];
    for(let j = 1; j < points.length; j++){
      lengths[j] = lengths[j - 1] + points[j].distanceTo(points[j - 1]);
    }
    const totalLength = lengths[points.length - 1];
    const uvs = geom.attributes.uv;
    for(let i = 0; i <= segments; i++){
      for(let j = 0; j < points.length; j++){
        const idx = i * points.length + j;
        uvs.setY(idx, lengths[j] / totalLength);
      }
    }
    uvs.needsUpdate = true;
  }
  return geom;
}

function handleGeometry(){
  const p = [
    new THREE.Vector3(0.00,0.75,0.0),
    new THREE.Vector3(0.43,0.79,0.18),
    new THREE.Vector3(0.78,0.52,0.30),
    new THREE.Vector3(0.92,0.08,0.33),
    new THREE.Vector3(0.83,-0.40,0.28),
    new THREE.Vector3(0.50,-0.73,0.16),
    new THREE.Vector3(0.00,-0.80,0.0)
  ];
  return new THREE.TubeGeometry(new THREE.CatmullRomCurve3(p), 120, 0.12, 18, false);
}
function shadowTexture(){
  const c=document.createElement('canvas'); c.width=320; c.height=320; const x=c.getContext('2d');
  const g=x.createRadialGradient(160,160,15,160,160,150);
  g.addColorStop(0,'rgba(66,43,39,.26)'); g.addColorStop(.44,'rgba(66,43,39,.11)'); g.addColorStop(1,'rgba(66,43,39,0)');
  x.fillStyle=g; x.fillRect(0,0,320,320);
  return new THREE.CanvasTexture(c);
}
function resize(){
  if(!renderer) return;
  const w=Math.max(1,activeStage.clientWidth), h=Math.max(1,activeStage.clientHeight);
  camera.aspect = w/h;
  if(h/w > 1.05) camera.fov = 31; else camera.fov = 34;
  camera.updateProjectionMatrix();
  renderer.setSize(w,h,false);
}
async function init(){
  drawArtwork();
  if(!canvas || !hero) return;

  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(34,1,.1,100);
  camera.position.set(0,0.34,7.95);

  renderer = new THREE.WebGLRenderer({canvas,antialias:true,alpha:true,preserveDrawingBuffer:true,powerPreference:'high-performance'});
  renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.7));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.01;

  texture = new THREE.CanvasTexture(artCanvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
  texture.wrapS = THREE.RepeatWrapping;
  texture.offset.x = .5;
  texture.needsUpdate = true;

  bodyMat = new THREE.MeshPhysicalMaterial({
    map:texture, roughness:.28, metalness:0, clearcoat:.45, clearcoatRoughness:.18,
    sheen:0.12, sheenRoughness:0.45, color:0xffffff
  });
  porcelainMat = new THREE.MeshPhysicalMaterial({
    color:COLORS.cream.rim, roughness:.22, metalness:0, clearcoat:.52, clearcoatRoughness:.17, sheen:0.12, sheenRoughness:0.4
  });
  innerMat = new THREE.MeshPhysicalMaterial({
    color:0xf7f0e7, roughness:.35, metalness:0, clearcoat:.25, clearcoatRoughness:.32, side:THREE.BackSide
  });
  coffeeMat = new THREE.MeshPhysicalMaterial({color:0x5c382a, roughness:.36, metalness:0, clearcoat:.08, clearcoatRoughness:.1});

  mug = new THREE.Group();
  mug.scale.setScalar(1.14);
  mug.position.y = -0.04;
  scene.add(mug);

  const outer = new THREE.Mesh(createBodyProfile(true), bodyMat);
  mug.add(outer);

  const inner = new THREE.Mesh(createBodyProfile(false), innerMat);
  inner.position.y = -0.02;
  mug.add(inner);

  const lip = new THREE.Mesh(new THREE.TorusGeometry(1.185,.06,22,140), porcelainMat);
  lip.rotation.x = Math.PI/2;
  lip.position.y = 1.055;
  mug.add(lip);

  const baseDisk = new THREE.Mesh(new THREE.CircleGeometry(0.87, 100), porcelainMat);
  baseDisk.rotation.x = -Math.PI/2;
  baseDisk.position.y = -1.045;
  mug.add(baseDisk);

  const foot = new THREE.Mesh(new THREE.TorusGeometry(0.93,.038,16,90), porcelainMat);
  foot.rotation.x = Math.PI/2;
  foot.position.y = -1.037;
  mug.add(foot);

  const insideBottom = new THREE.Mesh(new THREE.CircleGeometry(0.985, 100), innerMat.clone());
  insideBottom.material.side = THREE.DoubleSide;
  insideBottom.rotation.x = -Math.PI/2;
  insideBottom.position.y = -0.82;
  mug.add(insideBottom);

  const coffee = new THREE.Mesh(new THREE.CircleGeometry(1.01, 100), coffeeMat);
  coffee.rotation.x = -Math.PI/2;
  coffee.position.y = 0.965;
  mug.add(coffee);

  const coffeeRing = new THREE.Mesh(new THREE.RingGeometry(0.22,0.43,52), new THREE.MeshBasicMaterial({color:0xffffff, transparent:true, opacity:.09, side:THREE.DoubleSide}));
  coffeeRing.rotation.x = -Math.PI/2;
  coffeeRing.rotation.z = 0.35;
  coffeeRing.position.set(0.18,0.968,-0.06);
  mug.add(coffeeRing);

  const handle = new THREE.Mesh(handleGeometry(), porcelainMat);
  handle.position.set(1.12,-0.02,0.02);
  handle.rotation.y = -0.06;
  mug.add(handle);

  const shadow = new THREE.Mesh(new THREE.PlaneGeometry(4.5,2.35), new THREE.MeshBasicMaterial({map:shadowTexture(),transparent:true,depthWrite:false}));
  shadow.rotation.x = -Math.PI/2;
  shadow.position.y = -1.30;
  scene.add(shadow);

  const backGlow = new THREE.Mesh(new THREE.PlaneGeometry(5.2,5.2), new THREE.MeshBasicMaterial({color:0xffffff, transparent:true, opacity:.035, depthWrite:false}));
  backGlow.position.set(0,0.15,-1.7);
  scene.add(backGlow);

  scene.add(new THREE.AmbientLight(0xfffbf7,.55));
  scene.add(new THREE.HemisphereLight(0xfffaf4,0xb9c9d5,1.8));
  const key = new THREE.DirectionalLight(0xffffff,2.25); key.position.set(4.2,5.4,5.8); scene.add(key);
  const fill = new THREE.DirectionalLight(0xffd6e2,.78); fill.position.set(-3.0,1.7,3.8); scene.add(fill);
  const cool = new THREE.DirectionalLight(0xd9eff9,.86); cool.position.set(-1.8,3.0,-4.1); scene.add(cool);
  const low = new THREE.PointLight(0xfff0dd,.48,16); low.position.set(0,-1.2,4.6); scene.add(low);

  resize();
  renderReady = true;
  hero.classList.add('three-ready');
  renderer.setAnimationLoop(render);
}
function render(ms){
  if(!renderReady || document.hidden) return;
  const dt = lastFrame ? Math.min((ms-lastFrame)*.001,.05) : .016; lastFrame = ms;
  animationSeconds += dt;
  const ease = Math.min(1, dt * 9);
  yaw += (targetYaw-yaw) * ease;
  pitch += (targetPitch-pitch) * ease;
  mug.rotation.y = yaw;
  mug.rotation.x = pitch;
  mug.rotation.z = reducedMotion ? 0 : Math.sin(animationSeconds*.42)*.008;
  mug.position.y = -0.04 + (reducedMotion ? 0 : Math.sin(animationSeconds*.85)*.02);
  if(!dragging && !reducedMotion && performance.now()-lastInteraction > 10000 && !studio.classList.contains('is-active')){
    targetYaw += dt*.065;
  }
  renderer.render(scene,camera);
}
function setStage(isStudio){
  activeStage = isStudio ? studio : hero;
  if(isStudio){
    studio.appendChild(canvas);
    hero.classList.add('studio-active');
    studio.classList.add('is-active');
    studio.classList.toggle('three-ready', renderReady);
    studio.closest('.studio-viewer-pane')?.classList.toggle('three-ready', renderReady);
  }else{
    initialParent.insertBefore(canvas,initialNext);
    hero.classList.remove('studio-active');
    studio.classList.remove('is-active');
    studio.classList.remove('three-ready');
    studio.closest('.studio-viewer-pane')?.classList.remove('three-ready');
  }
  requestAnimationFrame(resize);
}
canvas.addEventListener('pointerdown',e=>{
  if(e.button!==0) return;
  dragging = true; lastX=e.clientX; lastY=e.clientY; lastInteraction=performance.now();
  canvas.setPointerCapture(e.pointerId);
});
canvas.addEventListener('pointermove',e=>{
  if(!dragging) return;
  const dx=e.clientX-lastX, dy=e.clientY-lastY;
  lastX=e.clientX; lastY=e.clientY;
  targetYaw += dx*.0135;
  targetPitch = THREE.MathUtils.clamp(targetPitch + dy*.0036, -.24, .12);
  lastInteraction = performance.now();
});
function release(){dragging=false; lastInteraction=performance.now();}
canvas.addEventListener('pointerup',release);
canvas.addEventListener('pointercancel',release);
canvas.addEventListener('lostpointercapture',release);
canvas.addEventListener('keydown',e=>{
  if(e.key==='ArrowLeft'||e.key==='ArrowRight'){
    e.preventDefault(); targetYaw += (e.key==='ArrowRight'?1:-1)*Math.PI/8; lastInteraction=performance.now();
  }
});
window.addEventListener('ct:mug-update',e=>{ Object.assign(options,e.detail); drawArtwork(); });
function rotateToNearest(angle){
  const mod = ((yaw % (Math.PI * 2)) + Math.PI * 3) % (Math.PI * 2) - Math.PI;
  const diff = ((angle - mod + Math.PI * 3) % (Math.PI * 2)) - Math.PI;
  return yaw + diff;
}
window.addEventListener('ct:studio-open',()=>{
  setStage(true);
  targetYaw = rotateToNearest(0);
  targetPitch = -0.08;
  lastInteraction = performance.now();
});
window.addEventListener('ct:studio-close',()=>setStage(false));
window.addEventListener('ct:mug-spin',()=>{ targetYaw += Math.PI*2; lastInteraction = performance.now(); });
window.addEventListener('ct:mug-front',()=>{
  targetYaw = rotateToNearest(0);
  targetPitch = -0.08; lastInteraction = performance.now();
});
window.addEventListener('ct:mug-back',()=>{
  targetYaw = rotateToNearest(Math.PI);
  targetPitch = -0.08; lastInteraction = performance.now();
});
window.CT_3D_CAPTURE = ()=>{
  if(!renderer || !renderReady){
    const link=document.createElement('a'); link.download='ct-artss-arte-personalizada.png'; link.href=artCanvas.toDataURL('image/png'); link.click(); return;
  }
  renderer.render(scene,camera);
  const link=document.createElement('a'); link.download='ct-artss-previa-caneca.png'; link.href=canvas.toDataURL('image/png'); link.click();
};
const observer = new ResizeObserver(resize); observer.observe(hero); observer.observe(studio);
window.addEventListener('resize',resize,{passive:true});
canvas.addEventListener('webglcontextlost',e=>{ e.preventDefault(); renderReady=false; hero.classList.remove('three-ready'); studio.classList.remove('three-ready'); studio.closest('.studio-viewer-pane')?.classList.remove('three-ready'); },{passive:false});
if(document.fonts?.ready) document.fonts.ready.then(()=>drawArtwork());
init().catch(err=>{
  console.warn('CT Artss 3D: flat fallback active:',err);
  hero.classList.remove('three-ready'); studio.classList.remove('three-ready'); studio.closest('.studio-viewer-pane')?.classList.remove('three-ready');
});
