
(() => {
  const menuButton = document.querySelector('#menuButton');
  const mobileMenu = document.querySelector('#mobileMenu');

  function setMenu(open){
    menuButton.setAttribute('aria-expanded', String(open));
    mobileMenu.classList.toggle('open', open);
    document.body.classList.toggle('menu-open', open);
  }

  menuButton.addEventListener('click', () => setMenu(menuButton.getAttribute('aria-expanded') !== 'true'));
  mobileMenu.querySelectorAll('a').forEach(a => a.addEventListener('click', () => setMenu(false)));

  document.querySelectorAll('.work-card button').forEach(btn => {
    btn.addEventListener('click', () => {
      // Mensagem única e neutra: Letícia conversa sobre os detalhes pessoalmente.
      const text = encodeURIComponent('Oi! Vim pelo seu site e queria encomendar uma caneca personalizada 💗');
      window.open(`https://wa.me/${window.CT_PHONE}?text=${text}`, '_blank', 'noopener');
    });
  });

  if (!window.gsap || !window.ScrollTrigger) return;
  gsap.registerPlugin(ScrollTrigger);

  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduce) return;

  const intro = gsap.timeline({defaults:{ease:'power4.out'}});
  intro
    .from('.site-header',{y:-18,autoAlpha:0,duration:.55})
    .from('.hero-copy .eyebrow',{y:10,autoAlpha:0,duration:.35},'-=.15')
    .from('.hero-copy h1',{y:24,autoAlpha:0,duration:.72},'-=.18')
    .from('.hero-lead',{y:16,autoAlpha:0,duration:.5},'-=.4')
    .from('.hero-actions > *',{y:12,autoAlpha:0,duration:.4,stagger:.08},'-=.3')
    .from('.hero-proof',{y:12,autoAlpha:0,duration:.45},'-=.2')
    .from('.hero-visual',{scale:.975,autoAlpha:0,duration:.78},'-=.7');

  gsap.to('.hero-visual', {
    y: 18,
    ease:'none',
    scrollTrigger:{trigger:'.hero',start:'top top',end:'bottom top',scrub:.5}
  });

  gsap.utils.toArray('.work-card').forEach((el, i) => {
    gsap.from(el,{y:28,autoAlpha:0,duration:.6,delay:(i%4)*.04,ease:'power4.out',scrollTrigger:{trigger:el,start:'top 88%'}});
  });

  gsap.utils.toArray('.process-list li').forEach(el => {
    gsap.from(el,{x:20,autoAlpha:0,duration:.55,ease:'power4.out',scrollTrigger:{trigger:el,start:'top 90%'}});
  });

  ['.price-head','.collection-art','.collection-content','.gift-image','.gift-copy','.about-media','.about-copy','.faq header','.faq-list','.final-cta'].forEach(sel=>{
    const el=document.querySelector(sel);
    if(!el) return;
    gsap.from(el,{y:26,autoAlpha:0,duration:.65,ease:'power4.out',scrollTrigger:{trigger:el,start:'top 88%'}});
  });

  gsap.utils.toArray('.mini-gallery figure').forEach((el,i)=>{
    gsap.from(el,{y:18,autoAlpha:0,duration:.5,delay:(i%3)*.03,ease:'power3.out',scrollTrigger:{trigger:el,start:'top 92%'}});
  });

  const navLinks=[...document.querySelectorAll('.desktop-nav a')];
  navLinks.forEach(link=>{
    const section=document.querySelector(link.getAttribute('href'));
    if(!section) return;
    ScrollTrigger.create({
      trigger:section,start:'top center',end:'bottom center',
      onToggle:self=>{
        if(self.isActive){navLinks.forEach(l=>l.classList.remove('active'));link.classList.add('active')}
      }
    });
  });
})();
