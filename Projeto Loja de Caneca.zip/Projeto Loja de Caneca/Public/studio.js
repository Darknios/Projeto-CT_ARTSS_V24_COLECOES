(() => {
  const modal = document.querySelector('#studioModal');
  const openButton = document.querySelector('#openStudio');
  const closeButton = document.querySelector('#closeStudio');
  const textInput = document.querySelector('#mugText');
  const count = document.querySelector('#mugTextCount');
  const upload = document.querySelector('#mugUpload');
  const uploadMessage = document.querySelector('#uploadMessage');
  const removeButton = document.querySelector('#removeMugImage');
  const themeNames = {cream:'Porcelana creme',pink:'Rosa delicado',blue:'Azul suave',mint:'Verde menta',yellow:'Amarelo claro'};
  const motifNames = {hearts:'Corações',stars:'Estrelinhas',flower:'Flores',none:'Sem detalhe'};
  const mugModels = { simple:{name:'Porcelana simples',price:'R$ 35,00'}, polymer:{name:'Sublimática de polímero',price:'R$ 29,90'}, sublimation:{name:'Sublimática de porcelana',price:'R$ 32,00'}, detailed:{name:'Porcelana detalhada',price:'R$ 40,00'} };
  const state = {text:'Feito com amor',color:'cream',motif:'hearts',image:null,imageName:'',drawing:null,model:'simple',photoStyle:'polaroid',photoScale:1.0,photoLayout:'front'};
  let previousFocus = null;
  const flatPreview=document.querySelector('#studioFlatPreview');
  const photoTools = document.querySelector('#studioPhotoTools');
  const photoStyles = document.querySelector('#photoStyles');
  const photoScaleInput = document.querySelector('#photoScale');
  const photoScaleValue = document.querySelector('#photoScaleValue');
  const photoLayouts = document.querySelector('#photoLayouts');
  const viewBackButton = document.querySelector('#viewBack');
  function isTransparentImage(img){
    try {
      const tc=document.createElement('canvas');tc.width=32;tc.height=32;
      const tcx=tc.getContext('2d',{willReadFrequently:true});
      tcx.drawImage(img,0,0,32,32);
      const d=tcx.getImageData(0,0,32,32).data;
      for(let i=3;i<d.length;i+=4){if(d[i]<220)return true;}
    }catch(e){}
    return false;
  }
  // An independent 2D preview keeps personalization functional if a device blocks WebGL/CDN.
  function paintFlatFallback(){
    const c=document.createElement('canvas');c.width=640;c.height=640;
    const x=c.getContext('2d');
    const colors={cream:'#fff8ef',pink:'#f5c4ce',blue:'#d6eafa',mint:'#ceebda',yellow:'#ffe2a2'};
    x.fillStyle=colors[state.color]||colors.cream;x.fillRect(0,0,640,640);
    x.textAlign='center';x.textBaseline='middle';
    x.fillStyle='#d75c79';x.font='43px Arial';
    if(state.motif==='hearts')[[100,120],[545,155],[110,500],[532,500]].forEach(([a,b])=>x.fillText('♥',a,b));
    else if(state.motif==='stars')[[100,120],[545,155],[110,500],[532,500]].forEach(([a,b])=>x.fillText('✦',a,b));
    else if(state.motif==='flower')[[100,120],[545,155],[110,500],[532,500]].forEach(([a,b])=>x.fillText('✿',a,b));

    const message = (state.text || '').trim();
    const isDuo = state.photoLayout === 'duo' && !!message;
    const hasArt = !!(state.image || state.drawing);

    if(state.image){
      const im = state.image;
      const baseMax = (message && !isDuo) ? 240 : 330;
      const maxBox = baseMax * (state.photoScale || 1.0);
      const ratio = Math.min(maxBox / im.naturalWidth, maxBox / im.naturalHeight);
      const w = im.naturalWidth * ratio, h = im.naturalHeight * ratio;
      const y = (message && !isDuo) ? 205 : 295;
      const isTransparent = isTransparentImage(im);
      const style = state.photoStyle || 'polaroid';

      x.save();
      if(style === 'circle' && !isTransparent){
        const dia = Math.min(w, h);
        const rad = dia / 2;
        // Borda circular branca
        x.fillStyle = '#ffffff';
        x.beginPath();
        x.arc(320, y, rad + 8, 0, Math.PI * 2);
        x.fill();
        x.beginPath();
        x.arc(320, y, rad, 0, Math.PI * 2);
        x.clip();
        x.drawImage(im, 320 - w/2, y - h/2, w, h);
      } else if(style === 'polaroid' && !isTransparent){
        const pad = 10;
        const cardW = w + pad * 2, cardH = h + pad * 2;
        x.fillStyle = '#ffffff';
        x.beginPath();
        x.roundRect(320 - cardW/2, y - cardH/2, cardW, cardH, 14);
        x.fill();
        x.beginPath();
        x.roundRect(320 - w/2, y - h/2, w, h, 8);
        x.clip();
        x.drawImage(im, 320 - w/2, y - h/2, w, h);
      } else {
        if(!isTransparent){
          x.beginPath();
          x.roundRect(320 - w/2, y - h/2, w, h, 12);
          x.clip();
        }
        x.drawImage(im, 320 - w/2, y - h/2, w, h);
      }
      x.restore();
    }
    if(state.drawing){
      const dy = (message && !isDuo) ? 205 : 295;
      x.drawImage(state.drawing, 165, dy - 96, 310, 193);
    }
    if(message && !isDuo){
      x.fillStyle='#142238';let font=78;
      do{x.font=`700 ${font}px Caveat, cursive`;if(x.measureText(message).width<530)break;font-=3;}while(font>34);
      x.fillText(message,320,hasArt?457:316,530);
    } else if(isDuo){
      x.fillStyle='rgba(20, 34, 56, 0.72)';
      x.font='600 24px DM Sans, sans-serif';
      x.fillText('Frase no verso ↺ (gire 180°)', 320, 480);
      x.fillStyle='#142238';
      x.font='700 36px Caveat, cursive';
      x.fillText(`"${message}"`, 320, 520, 530);
    } else if(!hasArt){
      x.fillStyle='#142238';
      x.font='700 78px Caveat, cursive';
      x.fillText('Sua ideia aqui',320,316,530);
    }
    flatPreview.src=c.toDataURL('image/png');flatPreview.hidden=false;
  }
  function sendUpdate(){paintFlatFallback();window.dispatchEvent(new CustomEvent('ct:mug-update',{detail:{...state}}));}
  function openStudio(){
    previousFocus=document.activeElement;
    modal.hidden=false;
    document.body.classList.add('studio-open');
    window.dispatchEvent(new CustomEvent('ct:studio-open'));
    closeButton.focus();
    sendUpdate();
  }
  function closeStudio(){
    modal.hidden=true;
    document.body.classList.remove('studio-open');
    window.dispatchEvent(new CustomEvent('ct:studio-close'));
    if(previousFocus && previousFocus.focus) previousFocus.focus();
  }
  openButton.addEventListener('click',openStudio);
  closeButton.addEventListener('click',closeStudio);
  document.querySelector('#studioBackdrop').addEventListener('click',closeStudio);
  modal.addEventListener('keydown',e=>{
    if(e.key==='Escape'){closeStudio();return;}
    if(e.key!=='Tab')return;
    const nodes=[...modal.querySelectorAll('button:not([disabled]):not([hidden]),input:not([disabled]):not([hidden]),select:not([disabled]),textarea:not([disabled]),a[href]')].filter(node=>node.getClientRects().length);
    const first=nodes[0],last=nodes[nodes.length-1];
    if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}
    else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}
  });
  textInput.addEventListener('input',()=>{state.text=textInput.value;count.textContent=`${textInput.value.length}/32`;sendUpdate();});
  count.textContent=`${textInput.value.length}/32`;
  window.addEventListener('ct:drawing-update', event => {
    state.drawing = event.detail?.drawing || null;
    sendUpdate();
  });
  paintFlatFallback();
  function selectIn(container,selected,attribute,key){
    container.querySelectorAll('button').forEach(btn=>{
      const active=btn===selected;
      btn.classList.toggle('selected',active);
      btn.setAttribute('aria-pressed',String(active));
    });
    state[key]=selected.dataset[attribute];sendUpdate();
  }
  document.querySelector('#studioModel').addEventListener('change',e=>{
    state.model = e.target.value;
    document.querySelector('#studioPrice').textContent = mugModels[state.model].price;
  });
  document.querySelector('#studioColors').addEventListener('click',e=>{
    const b=e.target.closest('[data-color]');if(b)selectIn(e.currentTarget,b,'color','color');
  });
  document.querySelector('#studioMotifs').addEventListener('click',e=>{
    const b=e.target.closest('[data-motif]');if(b)selectIn(e.currentTarget,b,'motif','motif');
  });
  upload.addEventListener('change',()=>{
    const file=upload.files&&upload.files[0];if(!file)return;
    if(!['image/png','image/jpeg','image/webp'].includes(file.type)||file.size>5*1024*1024){
      uploadMessage.textContent='Use PNG, JPG ou WebP com até 5 MB.';upload.value='';return;
    }
    const reader=new FileReader();
    reader.onload=()=>{
      const image=new Image();
      image.onload=()=>{
        state.image=image;state.imageName=file.name;
        uploadMessage.textContent=`Imagem pronta: ${file.name}. Prévia atualizada.`;
        if(photoTools) photoTools.hidden=false;
        removeButton.hidden=false;sendUpdate();
      };
      image.onerror=()=>{uploadMessage.textContent='Não foi possível ler esta imagem.';};
      image.src=reader.result;
    };
    reader.onerror=()=>{uploadMessage.textContent='Não foi possível carregar o arquivo.';};
    reader.readAsDataURL(file);
  });
  removeButton.addEventListener('click',()=>{
    state.image=null;state.imageName='';upload.value='';
    if(photoTools) photoTools.hidden=true;
    removeButton.hidden=true;
    uploadMessage.textContent='Imagem removida. Você pode enviar outra.';sendUpdate();
  });
  photoStyles?.addEventListener('click',e=>{
    const b=e.target.closest('[data-photo-style]');if(b)selectIn(photoStyles,b,'photoStyle','photoStyle');
  });
  photoLayouts?.addEventListener('click',e=>{
    const b=e.target.closest('[data-photo-layout]');if(b)selectIn(photoLayouts,b,'photoLayout','photoLayout');
  });
  photoScaleInput?.addEventListener('input',()=>{
    const val=Number(photoScaleInput.value)||100;
    if(photoScaleValue) photoScaleValue.textContent=`${val}%`;
    state.photoScale=val/100;sendUpdate();
  });
  document.querySelector('#spinMug').addEventListener('click',()=>window.dispatchEvent(new CustomEvent('ct:mug-spin')));
  document.querySelector('#resetView').addEventListener('click',()=>window.dispatchEvent(new CustomEvent('ct:mug-front')));
  viewBackButton?.addEventListener('click',()=>window.dispatchEvent(new CustomEvent('ct:mug-back')));
  document.querySelector('#downloadMug').addEventListener('click',()=>{
    if(typeof window.CT_3D_CAPTURE==='function'){window.CT_3D_CAPTURE();return;}
    const a=document.createElement('a');a.download='ct-artss-arte-personalizada.png';
    a.href=flatPreview.src;a.click();
  });
  document.querySelector('#orderCustomMug').addEventListener('click',()=>{
    if(window.CT_STOCK?.isSoldOut(window.CT_STOCK.modelIds[state.model])){
      const notice=document.querySelector('#studioStockNotice');if(notice)notice.textContent='Modelo esgotado. Escolha outro.';
      return;
    }
    // Não preencher estilo, modelo ou instruções; o cliente anexa a prévia PNG manualmente.
    const message='Oi! Vim pelo seu site e queria encomendar uma caneca personalizada 💗';
    window.open(`https://wa.me/5581998774915?text=${encodeURIComponent(message)}`,'_blank','noopener');
  });
})();
