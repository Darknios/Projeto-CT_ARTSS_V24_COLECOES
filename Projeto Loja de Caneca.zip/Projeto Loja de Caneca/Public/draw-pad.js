/* CT Artss · Drawing pad
   Transparent client-side artwork: never uploaded to Supabase. The output becomes
   an overlay in both the 3D mug texture and the 2D fallback preview. */
(() => {
  'use strict';
  const $ = selector => document.querySelector(selector);
  const toggle = $('#drawToggle');
  const panel = $('#drawPad');
  const canvas = $('#drawCanvas');
  if (!toggle || !panel || !canvas) return;

  const ctx = canvas.getContext('2d', {willReadFrequently:true});
  const width = canvas.width;
  const height = canvas.height;
  const brush = $('#drawBrush');
  const eraser = $('#drawEraser');
  const sizeInput = $('#drawSize');
  const sizeValue = $('#drawSizeValue');
  const colors = $('#drawColors');
  const customColor = $('#drawCustomColor');
  const undoButton = $('#drawUndo');
  const redoButton = $('#drawRedo');
  const clearButton = $('#drawClear');
  const downloadButton = $('#drawDownload');
  const status = $('#drawStatus');
  const surface = $('.draw-canvas-wrap');
  const MAX_HISTORY = 15;

  let color = '#142238';
  let size = Number(sizeInput.value) || 8;
  let tool = 'brush';
  let pointer = null;
  let lastPoint = null;
  let hasDrawing = false;
  const history = [ctx.getImageData(0, 0, width, height)];
  let historyIndex = 0;

  toggle.addEventListener('click', () => {
    const isOpening = panel.hidden;
    panel.hidden = !isOpening;
    toggle.setAttribute('aria-expanded', String(isOpening));
    toggle.innerHTML = isOpening ? 'Fechar quadro <span aria-hidden="true">↗</span>' : 'Abrir quadro <span aria-hidden="true">↘</span>';
    if (isOpening) panel.scrollIntoView({block:'nearest',behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});
  });

  function setTool(next){
    tool = next;
    brush.classList.toggle('active', tool === 'brush');
    eraser.classList.toggle('active', tool === 'eraser');
    brush.setAttribute('aria-pressed', String(tool === 'brush'));
    eraser.setAttribute('aria-pressed', String(tool === 'eraser'));
    canvas.style.cursor = tool === 'eraser' ? 'cell' : 'crosshair';
    status.textContent = tool === 'eraser' ? 'Borracha selecionada: apague os traços indesejados.' : 'Pincel selecionado: desenhe no quadro.';
  }
  brush.addEventListener('click', () => setTool('brush'));
  eraser.addEventListener('click', () => setTool('eraser'));

  function selectInk(next, selection){
    color = next;
    colors.querySelectorAll('[data-draw-color]').forEach(button => {
      const isSelected = button === selection;
      button.classList.toggle('active',isSelected);
      button.setAttribute('aria-pressed',String(isSelected));
    });
    $('.draw-color-custom').classList.toggle('active',!selection);
    setTool('brush');
  }
  colors.addEventListener('click', event => {
    const chosen = event.target.closest('[data-draw-color]');
    if (chosen) selectInk(chosen.dataset.drawColor,chosen);
  });
  customColor.addEventListener('input', () => selectInk(customColor.value,null));
  sizeInput.addEventListener('input', () => {
    size = Number(sizeInput.value);
    sizeValue.textContent = String(size);
  });

  function pointFromEvent(event){
    const rect = canvas.getBoundingClientRect();
    // CSS dimensions may differ wildly from intrinsic canvas resolution on mobile.
    // Always map pointer coordinates onto the 900x560 transparent art surface.
    return {
      x:Math.max(0,Math.min(width,(event.clientX-rect.left)*width/rect.width)),
      y:Math.max(0,Math.min(height,(event.clientY-rect.top)*height/rect.height))
    };
  }
  function inkSettings(event){
    ctx.globalCompositeOperation = tool === 'eraser' ? 'destination-out' : 'source-over';
    ctx.strokeStyle = tool === 'eraser' ? '#000000' : color;
    ctx.fillStyle = tool === 'eraser' ? '#000000' : color;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    const pressure = event.pointerType === 'pen' && event.pressure > 0 ? Math.max(.55,event.pressure) : 1;
    ctx.lineWidth = (tool === 'eraser' ? size * 2.3 : size) * pressure;
  }
  function stamp(point,event){
    inkSettings(event);
    ctx.beginPath();
    ctx.arc(point.x,point.y,ctx.lineWidth/2,0,Math.PI*2);
    ctx.fill();
    ctx.closePath();
    ctx.globalCompositeOperation='source-over';
  }
  function line(to,event){
    if (!lastPoint) return stamp(to,event);
    inkSettings(event);
    ctx.beginPath();
    ctx.moveTo(lastPoint.x,lastPoint.y);
    ctx.lineTo(to.x,to.y);
    ctx.stroke();
    ctx.closePath();
    ctx.globalCompositeOperation='source-over';
    lastPoint = to;
  }
  canvas.addEventListener('pointerdown',event => {
    if (pointer !== null || (event.pointerType === 'mouse' && event.button !== 0)) return;
    event.preventDefault();
    pointer = event.pointerId;
    lastPoint = pointFromEvent(event);
    canvas.setPointerCapture(event.pointerId);
    stamp(lastPoint,event);
  });
  canvas.addEventListener('pointermove',event => {
    if (pointer !== event.pointerId) return;
    event.preventDefault();
    // Coalesced events improve pen fidelity but are optional in older browsers.
    const events = typeof event.getCoalescedEvents === 'function' ? event.getCoalescedEvents() : [event];
    for (const item of events) line(pointFromEvent(item),item);
  });
  function hasVisiblePixels(imageData){
    const rgba = imageData.data;
    for (let i=3;i<rgba.length;i+=4) if (rgba[i] !== 0) return true;
    return false;
  }
  function updateButtons(){
    undoButton.disabled = historyIndex <= 0;
    redoButton.disabled = historyIndex >= history.length-1;
    clearButton.disabled = !hasDrawing;
    downloadButton.disabled = !hasDrawing;
    surface.classList.toggle('has-drawing',hasDrawing);
  }
  function notify(){
    const bitmap = ctx.getImageData(0,0,width,height);
    hasDrawing = hasVisiblePixels(bitmap);
    updateButtons();
    window.dispatchEvent(new CustomEvent('ct:drawing-update', {detail:{drawing:hasDrawing?canvas:null}}));
    return bitmap;
  }
  function checkpoint(){
    const bitmap = notify();
    history.splice(historyIndex+1);
    history.push(bitmap);
    if(history.length > MAX_HISTORY) history.shift();
    historyIndex=history.length-1;
    updateButtons();
    status.textContent = hasDrawing ? 'Arte aplicada na caneca! Continue desenhando ou salve o PNG.' : 'Quadro vazio. Faça um desenho para aplicar na caneca.';
  }
  function endStroke(event){
    if(pointer !== event.pointerId) return;
    pointer=null;
    lastPoint=null;
    if(canvas.hasPointerCapture?.(event.pointerId)) canvas.releasePointerCapture(event.pointerId);
    checkpoint();
  }
  canvas.addEventListener('pointerup',endStroke);
  canvas.addEventListener('pointercancel',endStroke);
  canvas.addEventListener('lostpointercapture',event => {
    if(pointer!==event.pointerId) return;
    pointer=null;
    lastPoint=null;
    checkpoint();
  });
  function restore(index){
    if(index<0 || index>=history.length) return;
    historyIndex=index;
    ctx.globalCompositeOperation='source-over';
    ctx.clearRect(0,0,width,height);
    ctx.putImageData(history[historyIndex],0,0);
    notify();
    status.textContent = 'Desenho atualizado na prévia da caneca.';
  }
  undoButton.addEventListener('click',()=>restore(historyIndex-1));
  redoButton.addEventListener('click',()=>restore(historyIndex+1));
  clearButton.addEventListener('click',()=>{
    ctx.globalCompositeOperation='source-over';
    ctx.clearRect(0,0,width,height);
    checkpoint();
    status.textContent='Desenho limpo. Se quiser, use Desfazer para recuperar a arte.';
  });
  downloadButton.addEventListener('click',()=>{
    if(!hasDrawing) return;
    const link=document.createElement('a');
    link.download='ct-artss-meu-desenho.png';
    link.href=canvas.toDataURL('image/png');
    link.click();
    status.textContent='PNG salvo. Anexe o desenho na conversa com a Letícia.';
  });
  updateButtons();
})();
