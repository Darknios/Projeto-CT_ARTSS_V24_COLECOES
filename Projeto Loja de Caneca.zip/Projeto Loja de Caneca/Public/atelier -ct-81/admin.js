/* CT Artss | painel reservado (sem service_role no navegador) */
(()=>{
  const $=sel=>document.querySelector(sel);
  const cfg=window.CT_SUPABASE||{};
  const loginView=$('#loginView'),dashboard=$('#dashboard'),actions=$('#headerActions');
  const tokenKey='ct_artss_v15_session';
  const pictures={
    'porcelana-simples':'../assets/preco-porcelana-simples.webp',
    'polimero':'../assets/preco-polimero.webp',
    'sublimacao-porcelana':'../assets/preco-sublimacao-porcelana.webp',
    'porcelana-detalhada':'../assets/preco-porcelana-detalhada.webp',
    'nome':'../assets/caneca-karina-editorial.webp',
    'familia':'../assets/caneca-davizinho-editorial.webp',
    'divertida':'../assets/caneca-divertida-editorial.webp',
    'pet':'../assets/caneca-pet-editorial.webp'
  };
  let db=null;
  let token=sessionStorage.getItem(tokenKey)||'';
  const say=(node,msg,success=false)=>{node.textContent=msg;node.classList.toggle('success',success);};
  function initClient(){
    if(db)return db;
    const url=(cfg.url||'').trim(),key=(cfg.publishableKey||'').trim();
    if(!url||!key)throw new Error('Supabase ainda não configurado. Preencha o arquivo supabase-config.js do site.');
    if(!window.supabase?.createClient)throw new Error('Biblioteca do Supabase não carregou. Verifique sua conexão.');
    db=window.supabase.createClient(url.replace(/\/$/,''),key,{auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false}});
    return db;
  }
  async function rpc(name,args){
    const {data,error}=await initClient().rpc(name,args);
    if(error)throw new Error(error.message);
    if(!data?.ok)throw new Error(data?.error||'Não foi possível realizar a operação.');
    return data;
  }
  function showLogin(){loginView.hidden=false;dashboard.hidden=true;actions.hidden=true;token='';sessionStorage.removeItem(tokenKey);}
  function showDashboard(username){loginView.hidden=true;dashboard.hidden=false;actions.hidden=false;$('#whoAmI').textContent=username;$('#newUsername').value=username;}
  function makeCard(row){
    const article=document.createElement('article');
    article.className='admin-item'+(row.is_sold_out?' sold':'');
    const imageWrap=document.createElement('div');imageWrap.className='admin-image';
    const img=document.createElement('img');img.src=pictures[row.id]||'../assets/ct-artss-logo.webp';img.alt='Imagem do item';img.loading='lazy';
    const label=document.createElement('span');label.className='admin-status';label.textContent=row.is_sold_out?'Esgotado':'Disponível';
    imageWrap.append(img,label);
    const info=document.createElement('div');info.className='admin-item-info';
    const h=document.createElement('h3');h.textContent=row.label;
    const p=document.createElement('p');p.textContent=row.is_sold_out?'Não é possível pedir pelo cartão correspondente.':'Visível e disponível na loja.';
    const button=document.createElement('button');button.type='button';button.className='toggle';button.textContent=row.is_sold_out?'↺ Marcar disponível':'× Marcar esgotado';
    button.setAttribute('aria-label',(row.is_sold_out?'Marcar disponível: ':'Marcar esgotado: ')+row.label);
    button.addEventListener('click',async()=>{
      button.disabled=true;button.textContent='Salvando…';
      try{await rpc('ct_admin_set_status',{p_token:token,p_id:row.id,p_sold_out:!row.is_sold_out});
        say($('#dashboardMessage'),`${row.label}: ${row.is_sold_out?'disponível':'esgotado'}. Atualizado no site.`,true);
        await refresh();
      }catch(e){say($('#dashboardMessage'),e.message);button.disabled=false;button.textContent=row.is_sold_out?'↺ Marcar disponível':'× Marcar esgotado';if(e.message.includes('Sessão'))showLogin();}
    });
    info.append(h,p,button);article.append(imageWrap,info);
    return article;
  }
  async function refresh(){
    try{
      const {data,error}=await initClient().from('ct_catalog_status').select('id,label,group_key,sort_order,is_sold_out').order('sort_order',{ascending:true});
      if(error)throw new Error(error.message);
      // Older databases may still contain the former 05 until the V24 SQL patch is run.
      // It is now a photo variant of model 04, never an independently sold model.
      const items=(data||[]).filter(row=>row.id!=='porcelana-criativa');
      $('#modelGrid').replaceChildren();$('#inspirationGrid').replaceChildren();
      for(const row of items){(row.group_key==='model'?$('#modelGrid'):$('#inspirationGrid')).appendChild(makeCard(row));}
      const sold=items.filter(row=>row.is_sold_out).length;
      $('#summary').replaceChildren();
      for(const txt of [`${items.length} itens cadastrados`,`${items.length-sold} disponíveis`,`${sold} esgotados`]){
        const chip=document.createElement('span');chip.textContent=txt;$('#summary').appendChild(chip);
      }
    }catch(e){say($('#dashboardMessage'),`Não consegui atualizar a lista: ${e.message}`);}
  }
  $('#loginForm').addEventListener('submit',async e=>{
    e.preventDefault();
    const btn=$('#loginSubmit');btn.disabled=true;say($('#loginMessage'),'Conferindo acesso…');
    try{
      const result=await rpc('ct_admin_login',{p_username:$('#loginUsername').value,p_password:$('#loginPassword').value});
      token=result.token;sessionStorage.setItem(tokenKey,token);$('#loginPassword').value='';showDashboard(result.username);
      say($('#loginMessage'),'');await refresh();
    }catch(err){say($('#loginMessage'),err.message);}finally{btn.disabled=false;}
  });
  $('#refresh').addEventListener('click',refresh);
  $('#logout').addEventListener('click',async()=>{
    try{if(token)await rpc('ct_admin_logout',{p_token:token});}catch(e){}showLogin();say($('#loginMessage'),'Você saiu do painel.',true);
  });
  // V22: permite mudar o login e a senha independentemente, sem invalidar a conta
  // se houver um erro de validação. Após salvar, verifica as credenciais novas.
  $('#showCredentialPasswords').addEventListener('change',e=>{
    const type=e.target.checked?'text':'password';
    for(const id of ['currentPassword','newPassword','confirmNewPassword'])$('#'+id).type=type;
  });
  $('#credentialsForm').addEventListener('submit',async e=>{
    e.preventDefault();
    const btn=$('#credentialsSubmit'),feedback=$('#credentialsMessage');
    const name=$('#newUsername').value.trim();
    const current=$('#currentPassword').value;
    const newPass=$('#newPassword').value;
    const confirm=$('#confirmNewPassword').value;
    const oldName=$('#whoAmI').textContent.trim();
    const changedName=name.toLowerCase()!==oldName.toLowerCase();
    if(!/^[a-zA-Z0-9._-]{3,32}$/.test(name)){
      say(feedback,'Login precisa ter de 3 a 32 caracteres (letras, números, ponto, _ ou -).');return;
    }
    if(!current){say(feedback,'Digite sua senha atual para confirmar a mudança.');return;}
    if(newPass!==confirm){say(feedback,'A confirmação da nova senha não confere.');return;}
    if(newPass && (newPass.length<8 || new TextEncoder().encode(newPass).length>72)){
      say(feedback,'Nova senha: de 8 a 72 caracteres (até 72 bytes).');return;
    }
    if(!changedName && !newPass){
      say(feedback,'Você não mudou nada. Preencha uma nova senha ou altere o login.');return;
    }
    btn.disabled=true;
    let saved=false,confirmedName=name;
    try{
      say(feedback,'Salvando o novo acesso…');
      const result=await rpc('ct_admin_update_access',{
        p_token:token,p_current_password:current,p_new_username:name,p_new_password:newPass
      });
      saved=true;
      confirmedName=result.username||name;
      // O SQL invalida todos os tokens antigos; não deixe um deles armazenado.
      token='';sessionStorage.removeItem(tokenKey);
      say(feedback,'Alteração salva. Conferindo as novas credenciais…');
      const check=await rpc('ct_admin_login',{
        p_username:confirmedName,p_password:newPass||current
      });
      token=check.token;sessionStorage.setItem(tokenKey,token);
      $('#credentialsForm').reset();$('#showCredentialPasswords').checked=false;
      for(const id of ['currentPassword','newPassword','confirmNewPassword'])$('#'+id).type='password';
      showDashboard(check.username);
      say(feedback,'Acesso alterado e testado com sucesso! Você continua conectado.',true);
      await refresh();
    }catch(err){
      if(saved){
        showLogin();$('#loginUsername').value=confirmedName;
        say($('#loginMessage'),'O banco confirmou a alteração, mas a entrada automática falhou. Entre usando o novo login e a nova senha; se necessário, atualize esta página.');
      }else{
        const msg=String(err?.message||'Não foi possível salvar o novo acesso.');
        const missing=/ct_admin_update_access|PGRST202|schema cache|Could not find the function/i.test(msg);
        say(feedback,missing?'Atualização pendente no banco: execute CT_ARTSS_V22_CORRECAO_TROCA_ACESSO.sql no Supabase e recarregue o ADM.':msg);
      }
    }finally{btn.disabled=false;}
  });
  async function restore(){
    if(!token)return;
    try{const result=await rpc('ct_admin_verify',{p_token:token});showDashboard(result.username);await refresh();}
    catch(e){showLogin();say($('#loginMessage'),'Entre para acessar o painel.');}
  }
  if(!(cfg.url||'').trim()||!(cfg.publishableKey||'').trim()){
    say($('#loginMessage'),'Antes do primeiro acesso, configure a URL e a chave pública em supabase-config.js.');
  }
  restore();
})();
