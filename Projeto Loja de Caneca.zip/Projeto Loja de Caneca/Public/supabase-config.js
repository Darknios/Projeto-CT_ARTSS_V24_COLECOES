/* CT Artss | Chave PUBLICÁVEL Supabase (não é secret/service_role).
 * Se criar outro projeto ou substituir a chave, edite apenas os campos abaixo.
 */
window.CT_SUPABASE = {
  url: 'https://tasliozpfzaznryqhrni.supabase.co',
  publishableKey: 'sb_publishable__QakG7cb3gf80AbM0bMKhw_n3wknklq'
};
