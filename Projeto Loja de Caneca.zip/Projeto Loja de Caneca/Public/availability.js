/* Vitrine pública: lê somente a disponibilidade. Não há credenciais de ADM aqui. */
(()=>{
  const ids={simple:'porcelana-simples',polymer:'polimero',sublimation:'sublimacao-porcelana',detailed:'porcelana-detalhada'};
  const known=new Map();
  window.CT_STOCK={modelIds:ids,configured:false,ready:false,connected:false,
    isSoldOut(id){return known.get(id)===true;},
    status(id){return known.has(id)?known.get(id):null;}
  };
  const config=window.CT_SUPABASE||{};
  const url=(config.url||'').trim();
  const key=(config.publishableKey||'').trim();
  const configured=/^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/i.test(url) && !!key;
  const stock=window.CT_STOCK;
  stock.configured=configured;
  if(!configured){return;} // Antes da configuração o layout da V14 continua utilizável.

  const original=new WeakMap();
  const cards=[...document.querySelectorAll('[data-stock-id]')];
  const modelSelect=document.querySelector('#studioModel');
  const orderStudio=document.querySelector('#orderCustomMug');
  const notice=document.querySelector('#studioStockNotice');
  let db=null;

  function badge(card){
    let el=card.querySelector('.stock-badge');
    if(!el){el=document.createElement('span');el.className='stock-badge';el.setAttribute('role','status');
      const photo=card.querySelector('.price-photo,.work-media')||card;photo.appendChild(el);}
    return el;
  }
  function applyCard(card){
    const value=stock.status(card.dataset.stockId);
    const sold=value===true;
    const unknown=value===null;
    card.classList.toggle('is-sold-out',sold);
    card.classList.toggle('stock-unavailable',unknown);
    const chip=badge(card);
    chip.textContent=sold?'Esgotado':(unknown?'Disponibilidade a consultar':'Disponível');
    chip.hidden=!sold && !unknown;
    const action=card.matches('.work-card')?card.querySelector('.work-card-copy button'):card.querySelector('.price-info a');
    if(!action)return;
    if(!original.has(action))original.set(action,{
      label:action.innerHTML,href:action.getAttribute('href'),target:action.getAttribute('target')
    });
    const old=original.get(action);
    if(sold){
      action.innerHTML='Esgotado';
      if(action.tagName==='A'){action.removeAttribute('href');action.removeAttribute('target');action.setAttribute('aria-disabled','true');action.tabIndex=-1;}
      else action.disabled=true;
    }else if(unknown){
      action.innerHTML='Consultar disponibilidade ↗';
      if(action.tagName==='A'){
        action.setAttribute('href',`https://wa.me/5581998774915?text=${encodeURIComponent('Oi! Vim pelo seu site e queria encomendar uma caneca personalizada 💗')}`);
        action.setAttribute('target','_blank');action.removeAttribute('aria-disabled');action.removeAttribute('tabindex');
      }else action.disabled=false;
    }else{
      action.innerHTML=old.label;
      if(action.tagName==='A'){if(old.href)action.setAttribute('href',old.href);if(old.target)action.setAttribute('target',old.target);action.removeAttribute('aria-disabled');action.removeAttribute('tabindex');}
      else action.disabled=false;
    }
  }
  function syncStudio(){
    if(!modelSelect)return;
    for(const opt of modelSelect.options){opt.disabled=stock.isSoldOut(ids[opt.value]);
      const bare=opt.textContent.replace(/\s+\(esgotado\)$/,'');
      opt.textContent=bare+(opt.disabled?' (esgotado)':'');}
    if(modelSelect.selectedOptions[0]?.disabled){
      const available=[...modelSelect.options].find(o=>!o.disabled);
      if(available){modelSelect.value=available.value;modelSelect.dispatchEvent(new Event('change',{bubbles:true}));}
    }
    const allSold=[...modelSelect.options].every(o=>o.disabled);
    orderStudio.disabled=allSold;
    if(notice)notice.textContent=allSold?'Todos os modelos estão esgotados no momento.':(!stock.connected?'Consulte a disponibilidade pelo WhatsApp.':'');
  }
  function render(){cards.forEach(applyCard);syncStudio();window.dispatchEvent(new CustomEvent('ct:stock-loaded'));
    const note=document.querySelector('.price-note');if(note)note.textContent=stock.connected?'Disponibilidade atualizada automaticamente. Arte e prazo combinados no WhatsApp.':'Consulte a disponibilidade e o prazo pelo WhatsApp.';}
  async function refresh(){
    try{
      if(!db){if(!window.supabase?.createClient)throw new Error('Cliente Supabase indisponível');
        db=window.supabase.createClient(url.replace(/\/$/,''),key,{auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false}});}
      const {data,error}=await db.from('ct_catalog_status').select('id,is_sold_out');
      if(error)throw error;
      known.clear();(data||[]).forEach(row=>known.set(row.id,row.is_sold_out));
      stock.ready=true;stock.connected=true;
    }catch(err){
      console.warn('CT Artss: disponibilidade temporariamente indisponível',err);
      known.clear();stock.ready=true;stock.connected=false;
    }
    render();
  }
  // Não mostrar um produto esgotado como disponível enquanto espera pelo banco.
  render();refresh();
  const interval=setInterval(()=>{if(!document.hidden)refresh();},45000);
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh();});
  window.addEventListener('ct:stock-refresh',refresh);
  window.addEventListener('beforeunload',()=>clearInterval(interval),{once:true});
})();
