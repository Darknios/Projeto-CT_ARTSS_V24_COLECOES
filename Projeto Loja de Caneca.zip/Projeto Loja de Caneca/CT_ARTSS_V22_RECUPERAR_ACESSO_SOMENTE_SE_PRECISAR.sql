-- SOMENTE SE VOCÊ PERDEU O ACESSO ATUAL: SQL de recuperação manual.
-- NÃO execute este arquivo para instalar a V22. É opcional.
-- Substitua os DOIS textos abaixo por credenciais escolhidas por você.
-- Jamais coloque a sua senha nos arquivos PUBLIC/ do Netlify.
do $ct_recover$
declare
  novo_login text := 'COLOQUE_SEU_NOVO_LOGIN';
  nova_senha text := 'COLOQUE_SUA_NOVA_SENHA';
begin
  if novo_login='COLOQUE_SEU_NOVO_LOGIN' or nova_senha='COLOQUE_SUA_NOVA_SENHA' then
    raise exception 'Preencha o novo login e a nova senha ANTES de executar este SQL.';
  end if;
  if novo_login !~ '^[a-zA-Z0-9._-]{3,32}$' then
    raise exception 'Login: use entre 3 e 32 caracteres simples.';
  end if;
  if length(nova_senha)<8 or octet_length(nova_senha)>72 then
    raise exception 'Senha: entre 8 caracteres e 72 bytes.';
  end if;
  update ct_private.admin_account
     set username=lower(novo_login),
         password_hash=extensions.crypt(nova_senha,extensions.gen_salt('bf',10)),
         failed_attempts=0,
         locked_until=null,
         updated_at=now()
   where id=1;
  if not found then raise exception 'Conta ADM não encontrada; instale o SQL inicial antes.'; end if;
  delete from ct_private.admin_session where token_hash is not null;
end;
$ct_recover$;
select 'Novo acesso definido. Reabra o ADM e use suas credenciais novas.' as resultado;
