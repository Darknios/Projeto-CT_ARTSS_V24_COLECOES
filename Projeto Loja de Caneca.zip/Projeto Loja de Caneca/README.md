# CT Artss V18 — Quadro de desenho integrado ao estúdio

A nova seção "Desenhe na sua caneca" fica dentro do modal de personalização. O usuário desenha com mouse, dedo ou caneta digital. Cada traço concluído atualiza o material da caneca 3D e a prévia 2D de contingência. A imagem enviada anteriormente, a cor escolhida, os detalhes e o nome/frase permanecem independentes. Há pincel, borracha, paleta, cor livre, espessura, desfazer/refazer, limpar e exportação PNG do desenho transparente.

**O desenho fica local no navegador e não é enviado automaticamente ao WhatsApp ou ao banco.** O cliente precisa salvar a imagem e anexá-la à conversa para que Letícia confirme a arte final.

Também foi corrigida a largura do campo `Tipo de caneca` no mobile, que ficava estreita quando a mensagem de disponibilidade do Supabase aparecia.

## Publicar mantendo o keepalive

1. A URL e a chave pública já estão preenchidas em `public/supabase-config.js`; confira antes de publicar caso tenha mudado o projeto.
2. Publique **este projeto completo** via Git ou Netlify CLI (na mesma instância `ctartss`), mantendo `netlify.toml`, `netlify/functions/ct-keepalive.mjs`, `public/` e as variáveis `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY` no Netlify.
3. Comando de build: `npm run build`; publish directory: `public`.
4. Confira no painel que `ct-keepalive` continua `Scheduled`, e acesse `/atelier-ct-81/` para confirmar o ADM.

O SQL incluído é a versão de instalação anterior (com 5 modelos). **Nenhum SQL novo é necessário** para a ferramenta de desenho. Não publique o SQL na pasta `public/`.

*Arrastar somente os arquivos estáticos de `public/` no Netlify Drop publica o editor, mas não garante a função agendada de keepalive.*


## V19 — acesso reservado pelo rodapé
- Ícone discreto de cadeado à esquerda de “Trabalhos”, no rodapé, para abrir `/atelier-ct-81/`.
- O cadeado é somente um atalho; o acesso continua exigindo login do Supabase.
- Nenhuma alteração no SQL, credenciais, disponibilidade, estúdio 3D, desenhos ou keepalive.
- Para manter o agendamento do keepalive, publique o PROJETO COMPLETO por Git/Netlify CLI.
- Na V20, `public/supabase-config.js` já contém os dados públicos desta loja. Confira-os se mudar o projeto ou renovar a chave.


## CT Artss V20 — pedidos e Supabase configurados
- A legenda pública e a legenda no SQL são **Para mães de pet**.
- Todos os CTAs de WhatsApp — catálogo, inspirações, presentes, rodapé, estúdio 3D e disponibilidade desconhecida — enviam apenas: `Oi! Vim pelo seu site e queria encomendar uma caneca personalizada 💗`.
- A prévia/desenho 3D continuam disponíveis para download; o cliente envia a imagem manualmente depois de abrir o WhatsApp.
- O Supabase PUBLICÁVEL já está preenchido em `public/supabase-config.js`; nunca use a secret/service_role no navegador.
- A função de keepalive lê `SUPABASE_URL` e `SUPABASE_PUBLISHABLE_KEY` do Netlify, se estiverem definidas; caso contrário usa os dados públicos informados para esta loja.
- Se o SQL anterior já foi executado, execute somente `ATUALIZAR_LEGENDA_ADM_SE_JA_INSTALADO.sql` para ajustar o nome visível dentro do painel. Não rode o SQL inteiro de novo por causa da legenda.
- Para preservar o keepalive, publique este PROJETO COMPLETO por Git ou Netlify CLI. Upload manual da pasta `public/` não implanta a função agendada.
- O endereço do painel: `https://ctartss.netlify.app/atelier-ct-81/` (após publicar esta atualização).


## V21 — Voltar à página inicial pelo ADM
- Um botão “← Voltar ao site” foi adicionado no cabeçalho do ADM, tanto antes quanto depois de autenticar.
- No mobile, o texto vira “← Site”. Destino relativo `../#inicio`, na mesma loja/domínio.
- Sem alterações no login, senha, banco, catálogo, editor de desenhos ou keepalive. Não é necessário executar SQL.
- Para aplicar apenas este ajuste no deploy existente, substitua somente `public/atelier-ct-81/index.html` e `public/atelier-ct-81/admin.css`. Dessa forma, nenhuma configuração anterior é afetada.


## CT Artss V22 — correção da troca de login/senha (IMPORTANTE)

Se o Supabase já possui tabelas instaladas, abra SQL Editor e execute SOMENTE
`CT_ARTSS_V22_CORRECAO_TROCA_ACESSO.sql`. Esse patch é idempotente e NÃO
redefine a conta atual nem altera estoque. Não é necessário reinstalar o SQL
completo. Depois publique a V22 (ou só seus arquivos administrativos) e
recarregue `/atelier-ct-81/` com Ctrl+F5.

- Troca apenas de senha: mantenha o login como está e preencha nova senha.
- Troca apenas de login: altere login e deixe nova senha/confirmar em branco.
- Ambos: mude os dois. A senha atual é sempre obrigatória.
- O banco encerra as sessões anteriores; o painel testa as novas credenciais
  automaticamente e só comunica sucesso após um novo login.
- Se não lembra mais a senha atual, use **somente se necessário** o arquivo
  `CT_ARTSS_V22_RECUPERAR_ACESSO_SOMENTE_SE_PRECISAR.sql`, edite os dois
  campos antes de executá-lo no Supabase. Esse arquivo nunca vai dentro de
  `public/`.
- Publicar projeto completo por Git ou Netlify CLI para preservar o keepalive.
  O ZIP de ajuste incremental atualiza somente os 3 arquivos de ADM; não altera
  o agendamento existente.


## V23 — correção específica: DELETE requires a WHERE clause
No projeto Supabase já instalado, rode APENAS `CT_ARTSS_V23_CORRECAO_SENHA.sql` pelo SQL Editor. Ele substitui as duas funções de alteração de credenciais sem mudar a senha atual, login ou estoque. Não rode o setup único novamente e não precisa republicar o site para resolver este erro. A troca de credenciais continua invalidando sessões existentes, agora com `where token_hash is not null`.

O SQL de setup único e a recuperação opcional nesta distribuição também receberam o mesmo ajuste para novas instalações. A função de keepalive foi preservada.


## V24 — Coleções por categoria, sem quinto preço
- Preços ficam em **4 cards** (01 simples R$35, 02 polímero R$29,90, 03 sublimática porcelana R$32, 04 porcelana detalhada R$40).
- No **01**, três canecas de nomes + foto da caneca branca com lettering; no **02**, foto de personagens + foto da frase do café; no **04**, foto das duas canecas de cactos + foto da caneca com foguete. As duas fotos aparecem na mesma peça; a miniatura pode ser tocada para trocar a imagem principal.
- O card independente 05 foi removido: a foto do foguete agora é uma **segunda referência do modelo 04**, com o mesmo preço e disponibilidade. A disponibilidade permanece por categoria, não por fotografia.
- Atualizados o seletor 3D, o controle de estoque e as imagens de preview do ADM para os quatro modelos.
- **Banco existente:** rode somente `CT_ARTSS_V24_FUNDIR_MODELO_05.sql` (sem reinstalar setup). O patch tem `DELETE` com `WHERE id='porcelana-criativa'` e preserva o estado de `porcelana-detalhada`.
- **Instalação nova:** `CT_ARTSS_SUPABASE_SETUP_UNICO.sql` já tem somente os quatro modelos. A V23 de correção de senha foi preservada.
- O keepalive Netlify, a chave pública configurada e o painel do ADM são preservados no projeto completo.
