-- CT ARTSS V24 | Atualização para banco JÁ instalado.
-- A foto da antiga Porcelana criativa agora integra o modelo 04 (Porcelana detalhada).
-- A disponibilidade e o preço do modelo 04 são preservados.
-- Não mexe nos logins, senhas, sessões, ou inspirações.
-- Não execute o setup único novamente se o projeto já estiver configurado.

begin;
  update public.ct_catalog_status
     set label='Porcelana detalhada · R$ 40,00'
   where id='porcelana-detalhada';

  delete from public.ct_catalog_status
   where id='porcelana-criativa';
commit;
