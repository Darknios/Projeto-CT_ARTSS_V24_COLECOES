-- Executar apenas se você JÁ instalou o SQL da versão anterior.
-- Atualiza somente a legenda no ADM; não altera disponibilidade, credenciais ou sessões.
update public.ct_catalog_status
set label = 'Inspiração · Para mães de pet', updated_at = now()
where id = 'pet';
