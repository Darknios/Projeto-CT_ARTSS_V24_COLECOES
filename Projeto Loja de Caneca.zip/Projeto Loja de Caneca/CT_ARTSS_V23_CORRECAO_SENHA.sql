-- CT ARTSS V23 | HOTFIX do erro "DELETE requires a WHERE clause"
-- Execute ESTE arquivo no Supabase > SQL Editor > RUN, UMA VEZ.
-- Seguro para o banco existente: não redefine seu login ou senha,
-- não mexe em catálogo nem altera a tabela de sessões ao executar.
-- Apenas substitui o código das funções de troca de acesso.
-- Motivo: extensão pg_safeupdate exige WHERE explícito no DELETE.
-- token_hash é a chave primária NOT NULL; esta condição encerra todas as
-- sessões somente QUANDO uma mudança de credenciais for realizada.

begin;

-- Compatibilidade com painel anterior (V15-V21).
create or replace function public.ct_admin_change_credentials(
  p_token text,p_current_password text,p_new_username text,p_new_password text
)
returns jsonb
language plpgsql security definer set search_path = ''
as $function$
declare a ct_private.admin_account%rowtype;
begin
  if not ct_private.session_valid(p_token) then
    return jsonb_build_object('ok',false,'error','Sessão expirada. Entre novamente.');
  end if;
  if p_current_password is null or p_new_username is null or p_new_password is null then
    return jsonb_build_object('ok',false,'error','Preencha todos os campos.');
  end if;
  if p_new_username !~ '^[a-zA-Z0-9._-]{3,32}$' or length(p_new_password)<8
     or length(p_new_password)>72 then
    return jsonb_build_object('ok',false,'error','Login: 3–32 caracteres simples. Senha: 8–72 caracteres.');
  end if;
  select * into a from ct_private.admin_account where id=1 for update;
  if extensions.crypt(p_current_password,a.password_hash)<>a.password_hash then
    return jsonb_build_object('ok',false,'error','A senha atual está incorreta.');
  end if;
  update ct_private.admin_account set
    username=lower(p_new_username),
    password_hash=extensions.crypt(p_new_password,extensions.gen_salt('bf',10)),
    updated_at=now(),failed_attempts=0,locked_until=null
    where id=1;
  delete from ct_private.admin_session where token_hash is not null;
  return jsonb_build_object('ok',true,'message','Login e senha alterados. Entre novamente.');
end;
$function$;

-- Painel atual (V22+): troca de senha/login independente.
create or replace function public.ct_admin_update_access(
  p_token text,
  p_current_password text,
  p_new_username text,
  p_new_password text
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $ct_v22$
declare
  a ct_private.admin_account%rowtype;
  v_name text;
  v_hash text;
  v_change_name boolean;
  v_change_password boolean;
begin
  if not ct_private.session_valid(p_token) then
    return jsonb_build_object('ok',false,'error','Sessão expirada. Entre novamente no ADM.');
  end if;

  if p_current_password is null or length(p_current_password)=0 then
    return jsonb_build_object('ok',false,'error','Informe a senha atual para confirmar a alteração.');
  end if;

  select * into a from ct_private.admin_account where id=1 for update;
  if not found then
    return jsonb_build_object('ok',false,'error','Conta administrativa não encontrada.');
  end if;

  if extensions.crypt(p_current_password,a.password_hash) is distinct from a.password_hash then
    return jsonb_build_object('ok',false,'error','A senha atual não confere. O acesso não foi modificado.');
  end if;

  v_name := lower(btrim(coalesce(p_new_username,'')));
  if v_name='' then v_name:=a.username; end if;
  if v_name !~ '^[a-z0-9._-]{3,32}$' then
    return jsonb_build_object('ok',false,'error','Login: use 3 a 32 caracteres (letras, números, ponto, _ ou -).');
  end if;

  v_change_name := v_name is distinct from a.username;
  v_change_password := nullif(p_new_password,'') is not null;

  if v_change_password and (length(p_new_password)<8 or octet_length(p_new_password)>72) then
    return jsonb_build_object('ok',false,'error','Nova senha: mínimo de 8 caracteres e máximo de 72 bytes.');
  end if;

  if v_change_password and extensions.crypt(p_new_password,a.password_hash)=a.password_hash then
    return jsonb_build_object('ok',false,'error','A nova senha deve ser diferente da senha atual.');
  end if;

  if not v_change_name and not v_change_password then
    return jsonb_build_object('ok',false,'error','Nada foi alterado. Preencha uma nova senha ou mude o login.');
  end if;

  v_hash := a.password_hash;
  if v_change_password then
    v_hash:=extensions.crypt(p_new_password,extensions.gen_salt('bf',10));
  end if;

  update ct_private.admin_account
     set username=v_name,
         password_hash=v_hash,
         failed_attempts=0,
         locked_until=null,
         updated_at=now()
   where id=1;

  -- A troca encerra todas as sessões antigas. O novo ADM verifica as credenciais
  -- realizando um novo login logo depois desta confirmação do banco.
  delete from ct_private.admin_session where token_hash is not null;

  return jsonb_build_object(
    'ok',true,
    'username',v_name,
    'changed_login',v_change_name,
    'changed_password',v_change_password,
    'flow_version',22,
    'message','Alteração salva no banco. Entre novamente com os novos dados.'
  );
end;
$ct_v22$;

revoke all on function public.ct_admin_change_credentials(text,text,text,text) from public, anon, authenticated;
grant execute on function public.ct_admin_change_credentials(text,text,text,text) to anon, authenticated;
revoke all on function public.ct_admin_update_access(text,text,text,text) from public, anon, authenticated;
grant execute on function public.ct_admin_update_access(text,text,text,text) to anon, authenticated;

notify pgrst, 'reload schema';
commit;

select 'V23 instalada. Recarregue o ADM e tente trocar a senha normalmente.' as resultado;
