/* CT ARTSS | scheduled Supabase activity check.
 * Netlify deploy invokes this automatically three times a day.
 * No write operation, no private token, no direct visitor dependency.
 * View last success/failure in Netlify > Logs > Functions > ct-keepalive.
 */
export default async function ctKeepalive() {
  const started = new Date().toISOString();
  // Public publishable credentials only; env vars can override if the project/key changes.
  const rawURL = (process.env.SUPABASE_URL || 'https://tasliozpfzaznryqhrni.supabase.co').trim();
  const key = (process.env.SUPABASE_PUBLISHABLE_KEY || process.env.SUPABASE_ANON_KEY || 'sb_publishable__QakG7cb3gf80AbM0bMKhw_n3wknklq').trim();

  if (!rawURL || !key) {
    console.error(`[CT Keepalive] ${started} CONFIG_ERROR: configure SUPABASE_URL and SUPABASE_PUBLISHABLE_KEY in Netlify Environment variables (scope: Functions).`);
    throw new Error('CT keepalive: missing Supabase environment variables');
  }
  let url;
  try {
    url = new URL(rawURL);
    if (url.protocol !== 'https:' || !url.hostname) throw new Error('Invalid URL');
  } catch {
    console.error(`[CT Keepalive] ${started} CONFIG_ERROR: SUPABASE_URL must be a valid https URL.`);
    throw new Error('CT keepalive: invalid SUPABASE_URL');
  }

  // A real, tiny DB query on the public catalogue. No mutation or auth account use.
  // Unique query string discourages intermediate cache serving a stale response.
  const api = new URL('/rest/v1/ct_catalog_status', url);
  api.searchParams.set('select', 'id');
  api.searchParams.set('limit', '1');

  let lastError;
  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      const response = await fetch(api, {
        method: 'GET',
        headers: {
          apikey: key, // Publishable keys are NOT JWTs: never send them as Bearer.
          Accept: 'application/json',
          'Cache-Control': 'no-store'
        },
        signal: AbortSignal.timeout(10000)
      });
      if (!response.ok) {
        throw new Error(`Supabase REST HTTP ${response.status}`);
      }
      const rows = await response.json();
      if (!Array.isArray(rows)) throw new Error('Unexpected database response');
      console.log(`[CT Keepalive] OK ${new Date().toISOString()} | database answered | rows=${rows.length} | attempt=${attempt}`);
      return;
    } catch (error) {
      lastError = error;
      console.warn(`[CT Keepalive] attempt=${attempt}/2 failed: ${error.message}`);
      if (attempt < 2) await new Promise(resolve => setTimeout(resolve, 900));
    }
  }
  // Make failures visible to the Netlify Functions dashboard/logs.
  console.error(`[CT Keepalive] FAIL ${new Date().toISOString()} | ${lastError?.message || 'Unknown error'}`);
  throw lastError || new Error('CT keepalive failed');
}
